package org.seasar.flex2.rpc.remoting.service.annotation;

@RemotingService
public class TestRemotingService {

}
