package org.seasar.flex2.rpc.amf.gateway.service.annotation;

public class TestServiceClass {

}
