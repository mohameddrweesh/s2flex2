package org.seasar.flex2.rpc.amf.gateway.service.annotation;

/**
 * 
 * org.seasar.flex2.rpc.amf.gateway.service.annotation.AmfRemotingService
 * @AmfRemotingService
 *
 */
public class TestAmfRemotingServiceFull {

}
