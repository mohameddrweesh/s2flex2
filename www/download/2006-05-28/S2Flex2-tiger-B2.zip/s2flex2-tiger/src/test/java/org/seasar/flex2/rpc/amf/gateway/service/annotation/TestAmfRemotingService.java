package org.seasar.flex2.rpc.amf.gateway.service.annotation;

@AmfRemotingService
public class TestAmfRemotingService {

}
