package org.seasar.flex2.rpc.amf.data.factory.impl;

public class Amf3BodyFactoryImpl extends AmfBodyFactoryImpl {
    
    private final String responseTarget = "";

    protected String getResponseTarget() {
        return responseTarget;
    }
}
