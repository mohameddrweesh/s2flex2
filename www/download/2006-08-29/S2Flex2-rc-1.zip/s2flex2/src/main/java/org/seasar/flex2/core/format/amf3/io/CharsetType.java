package org.seasar.flex2.core.format.amf3.io;

public interface CharsetType {
    static final String UTF8 = "UTF-8";
}
