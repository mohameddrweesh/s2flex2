package org.seasar.flex2.rpc.remoting.service.annotation;

public class TestRemotingService {
    public static final String REMOTING_SERVICE = "testRemotingService";
}
