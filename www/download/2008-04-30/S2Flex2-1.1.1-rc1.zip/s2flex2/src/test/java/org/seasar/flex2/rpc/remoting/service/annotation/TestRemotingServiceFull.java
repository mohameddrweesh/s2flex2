package org.seasar.flex2.rpc.remoting.service.annotation;

public class TestRemotingServiceFull {
    public static final String REMOTING_SERVICE = "testRemotingServiceFull";
}
