package org.seasar.flex2.core.format.amf0.io.writer;

import org.seasar.flex2.core.format.amf.io.writer.AmfDataWriter;

public interface Amf0DataWriter extends AmfDataWriter {
}