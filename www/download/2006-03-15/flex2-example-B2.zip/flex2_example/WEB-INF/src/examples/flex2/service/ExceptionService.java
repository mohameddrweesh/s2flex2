package examples.flex2.service;

public interface ExceptionService {
	public void getExService(String serviceName);
		
}
