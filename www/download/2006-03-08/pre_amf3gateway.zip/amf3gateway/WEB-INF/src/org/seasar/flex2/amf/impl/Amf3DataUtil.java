package org.seasar.flex2.amf.impl;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.UTFDataFormatException;
import java.io.UnsupportedEncodingException;
import java.util.Date;

import javax.xml.parsers.DocumentBuilder;

import org.seasar.framework.beans.BeanDesc;
import org.seasar.framework.beans.PropertyDesc;
import org.seasar.framework.beans.factory.BeanDescFactory;
import org.seasar.framework.util.DocumentBuilderFactoryUtil;
import org.seasar.framework.util.DocumentBuilderUtil;
import org.seasar.framework.util.DomUtil;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * AMF3�f�[�^�֘A���[�e�B���e�B�N���X
 * 
 * 
 *
 */
public class Amf3DataUtil {
    
    /**
     * @param object
     * @param props_num
     * @param prop_names
     * @param prop_values
     */
    public static void fillProperties(Object object, int props_num, String[] prop_names, Object[] prop_values) {
        BeanDesc beanDesc = BeanDescFactory.getBeanDesc(object.getClass());
        for (int i = 0; i < props_num; i++) {
            if (beanDesc.hasPropertyDesc(prop_names[i])) {
                PropertyDesc pd = beanDesc.getPropertyDesc(prop_names[i]);
                if (pd.hasWriteMethod()) {
                    pd.setValue(object, prop_values[i]);
                }
            }
        }
    }
    /**
     * @param ms
     * @return
     */
    public static Date toDate(double ms) {
        Date date = new Date((long) ms);
        return date;
    }
    
    /**
     * @param list
     * @param byte_len
     * @return
     */
    public static Integer toInteger(int[] list, int byte_len) {

        int int_data = 0;
        int offset = 0;
        for (int i = list.length; i > 0; i--) {
            if (list[i - 1] != 0x00) {
                offset = (byte_len - i) * 7;
                int_data |= (list[i - 1] << offset);
            }
        }
        return new Integer(int_data);
    }
    

    /**
     * @param bytearr
     * @param utflen
     * @return
     * @throws UTFDataFormatException
     */
    public static String toStringModifiedUTF8(byte[] bytearr, int utflen) throws UTFDataFormatException{
        
        char[] chararr = new char[utflen * 2];

        int c, char2, char3;
        int count = 0;
        int chararr_count = 0;

        while (count < utflen) {
            c = (int) bytearr[count] & 0xff;
            if (c > 127)
                break;
            count++;
            chararr[chararr_count++] = (char) c;
        }

        while (count < utflen) {
            c = (int) bytearr[count] & 0xff;
            switch (c >> 4) {
                case 0:
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                case 6:
                case 7:
                    /* 0xxxxxxx */
                    count++;
                    chararr[chararr_count++] = (char) c;
                    break;
                case 12:
                case 13:
                    /* 110x xxxx 10xx xxxx */
                    count += 2;
                    if (count > utflen){
                        throw new UTFDataFormatException(
                                "malformed input: partial character at end");
                    }
                    char2 = (int) bytearr[count - 1];
                    if ((char2 & 0xC0) != 0x80){
                        throw new UTFDataFormatException(
                                "malformed input around byte " + count);
                    }
                        chararr[chararr_count++] = (char) (((c & 0x1F) << 6) | (char2 & 0x3F));
                    break;
                case 14:
                    /* 1110 xxxx 10xx xxxx 10xx xxxx */
                    count += 3;
                    if (count > utflen)
                        throw new UTFDataFormatException(
                                "malformed input: partial character at end");
                    char2 = (int) bytearr[count - 2];
                    char3 = (int) bytearr[count - 1];
                    if (((char2 & 0xC0) != 0x80) || ((char3 & 0xC0) != 0x80))
                        throw new UTFDataFormatException(
                                "malformed input around byte " + (count - 1));
                    chararr[chararr_count++] = (char) (((c & 0x0F) << 12)
                            | ((char2 & 0x3F) << 6) | ((char3 & 0x3F) << 0));
                    break;
                default:
                    /* 10xx xxxx, 1111 xxxx */
                    throw new UTFDataFormatException(
                            "malformed input around byte " + count);
            }
        }
        // The number of chars produced may be less than utflen
        return new String(chararr, 0, chararr_count);
    }
    


    /**
     * @param bytearr
     * @param utflen
     * @return
     */
    public static String toStringUTF8(byte[] bytearr, int utflen){
        try {
            return new String(bytearr, 0, utflen, "utf-8");
        } catch (UnsupportedEncodingException e) {
            return null;
        }
    }
    


    /**
     * @param xml_data
     * @return
     * @throws UnsupportedEncodingException
     */
    public static Document toXmlDocument(String xml_data) throws UnsupportedEncodingException {
        ByteArrayInputStream bain = new ByteArrayInputStream(xml_data
                .getBytes("utf-8"));
        BufferedInputStream bis = new BufferedInputStream(bain);

        DocumentBuilder builder = DocumentBuilderFactoryUtil
                .newDocumentBuilder();
        return DocumentBuilderUtil.parse(builder, bis);
    }
    
    /**
     * @param str
     * @param utflen
     * @return
     * @throws UTFDataFormatException
     * @throws UnsupportedEncodingException
     */
    public static byte[] toBytesModifiedUTF8(String str, int utflen) throws UTFDataFormatException, UnsupportedEncodingException {
        int strlen = str.length();
        int c=0;
        int count = 0;

        byte[] bytearr = new byte[(utflen * 2)];

        int i = 0;
        for (i = 0; i < strlen; i++) {
            c = str.charAt(i);
            if (!((c >= 0x0001) && (c <= 0x007F))) {
                break;
            }
            bytearr[count++] = (byte) c;
        }

        for (; i < strlen; i++) {
            c = str.charAt(i);
            if ((c >= 0x0001) && (c <= 0x007F)) {
                bytearr[count++] = (byte) c;

            } else if (c > 0x07FF) {
                bytearr[count++] = (byte) (0xE0 | ((c >> 12) & 0x0F));
                bytearr[count++] = (byte) (0x80 | ((c >> 6) & 0x3F));
                bytearr[count++] = (byte) (0x80 | ((c >> 0) & 0x3F));
            } else {
                bytearr[count++] = (byte) (0xC0 | ((c >> 6) & 0x1F));
                bytearr[count++] = (byte) (0x80 | ((c >> 0) & 0x3F));
            }
        }

        return bytearr;
    }
    
    
    /**
     * @param str
     * @return
     */
    public static int getStringLengthModifiedUTF8(String str) {
        int strlen = str.length();
        int utflen = 0;
        int c = 0;

        /* use charAt instead of copying String to char array */
        for (int i = 0; i < strlen; i++) {
            c = str.charAt(i);
            if ((c >= 0x0001) && (c <= 0x007F)) {
                utflen++;
            } else if (c > 0x07FF) {
                utflen += 3;
            } else {
                utflen += 2;
            }
        }

        if (utflen > 65535) {
            //throw new UTFDataFormatException("encoded string too long: " + utflen + " bytes");
            return -1;
        }
        return utflen;
    }
    


    /**
     * @param document
     * @return
     */
    public static String toXmlString(Document document) {
        Element element = document.getDocumentElement();
        return DomUtil.toString(element);
    }
    
    

    /**
     * @param value
     * @return
     */
    public static int[] toVariableBytes(Integer value) {
        int[] list = new int[4];

        for (int i = 0; i < list.length; i++) {
            list[i] = value & 0x7F;
            value = value >>> 7;
            if (value <= 0) {
                break;
            }
        }
        return list;
    }
}
