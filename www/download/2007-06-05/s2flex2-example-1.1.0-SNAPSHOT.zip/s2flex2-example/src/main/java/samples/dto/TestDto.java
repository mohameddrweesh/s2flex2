package samples.dto;

import org.w3c.dom.Document;

public class TestDto {
        private Document xmlData;

	public Document getXmlData() {
		return xmlData;
	}

	public void setXmlData(Document xmlData) {
		this.xmlData = xmlData;
	}
}