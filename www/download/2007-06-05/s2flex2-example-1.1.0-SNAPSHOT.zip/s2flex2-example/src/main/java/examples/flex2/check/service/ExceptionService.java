package examples.flex2.check.service;

public interface ExceptionService {
	public void getExService(String serviceName);
		
}
