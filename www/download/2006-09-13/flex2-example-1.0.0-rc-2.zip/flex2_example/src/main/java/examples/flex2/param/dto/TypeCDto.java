package examples.flex2.param.dto;

public class TypeCDto {
	private TypeADto a;
	private TypeBDto b;
	
	public TypeADto getA() {
		return a;
	}
	public void setA(TypeADto a) {
		this.a = a;
	}
	public TypeBDto getB() {
		return b;
	}
	public void setB(TypeBDto b) {
		this.b = b;
	}

}
